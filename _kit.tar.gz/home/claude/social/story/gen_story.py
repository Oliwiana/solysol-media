# usage: python3 gen_story.py s.json  -> html/story-1..3.html (1080x1920)
import json,sys,os
d=json.load(open(sys.argv[1]))
F='/home/claude/tools/node_modules/@fontsource/'
def ff(fam,dirn,ws,ital=False):
    out=''
    for w in ws:
        for sub in ('latin','latin-ext'):
            st='italic' if ital else 'normal'
            out+=f"@font-face{{font-family:'{fam}';font-weight:{w};font-style:{st};src:url(file://{F}{dirn}/files/{dirn}-{sub}-{w}-{st}.woff2)}}"
    return out
FONTS=ff('Cormorant Garamond','cormorant-garamond',(500,600))+ff('Cormorant Garamond','cormorant-garamond',(500,),True)+ff('Inter','inter',(400,500,600,700))+ff('Oswald','oswald',(500,600,700))+ff('Anton','anton',(400,))
INK='#171513';IV='#F6F1E8';ORG='#C8692E';ORL='#E0874F'
CG="font-family:'Cormorant Garamond',serif;";OS="font-family:Oswald,sans-serif;";AN="font-family:Anton,sans-serif;"
def page(body):
    return f"""<!DOCTYPE html><html><head><meta charset="utf-8"><style>{FONTS}*{{margin:0;padding:0;box-sizing:border-box}}body{{width:1080px;height:1920px;overflow:hidden;background:{INK};color:{IV};font-family:Inter,sans-serif;position:relative}}</style></head><body>{body}</body></html>"""
def head(n,title,sub,photo,pos='center'):
    return f"""<div style="position:absolute;left:0;right:0;top:0;height:820px;overflow:hidden"><img src="file:///home/claude/photos_raw/{photo}" style="width:100%;height:100%;object-fit:cover;object-position:{pos}"></div>
<div style="position:absolute;left:0;right:0;top:0;height:822px;background:linear-gradient(180deg,rgba(23,21,19,.55) 0%,rgba(23,21,19,.1) 35%,rgba(23,21,19,.55) 70%,{INK} 100%)"></div>
<div style="position:absolute;left:70px;right:70px;top:150px;display:flex;justify-content:space-between;align-items:center;{OS}font-size:26px;font-weight:600;letter-spacing:.2em">
<span>SOL <i style="{CG}color:{ORL};font-size:34px;letter-spacing:0">y</i> SÓL</span><span style="color:{ORL}">{n}/3</span></div>
<div style="position:absolute;left:70px;right:70px;top:560px">
<div style="{OS}font-size:28px;font-weight:600;letter-spacing:.24em;color:{ORL}">{sub}</div>
<div style="{AN}font-size:118px;line-height:1.02;margin-top:14px;text-transform:uppercase">{title}</div></div>"""
def foot(t='WIĘCEJ: SOLYSOL.PL'):
    return f"""<div style="position:absolute;left:70px;right:70px;bottom:150px;display:flex;justify-content:space-between;border-top:2px solid rgba(246,241,232,.25);padding-top:26px;{OS}font-size:26px;font-weight:600;letter-spacing:.16em"><span style="opacity:.7">{d['date']}</span><span style="color:{ORL}">{t}</span></div>"""
def rows(items,w=300):
    return ''.join(f"""<div style="display:grid;grid-template-columns:{w}px 1fr;gap:24px;padding:24px 0;border-bottom:1.5px solid rgba(246,241,232,.18);align-items:baseline"><span style="{CG}font-size:52px;font-weight:600;color:{ORL};line-height:1">{a}</span><div><div style="font-size:36px;font-weight:600;line-height:1.2">{b}</div>{f'<div style="font-size:27px;color:#C9BFB0;margin-top:6px;line-height:1.3">{c}</div>' if c else ''}</div></div>""" for a,b,c in items)
def box(label,text):
    return f"""<div style="background:{ORL};color:{INK};padding:26px 32px;margin-top:34px"><div style="{OS}font-size:24px;font-weight:700;letter-spacing:.2em">{label}</div><div style="font-size:33px;font-weight:600;line-height:1.3;margin-top:8px">{text}</div></div>"""
os.makedirs('html',exist_ok=True)
w=d['weather']
s1=head(1,'Dziś na<br>wybrzeżu','POGODA · '+d['day'],d['photos'][0],d.get('pos0','center'))+f"""<div style="position:absolute;left:70px;right:70px;top:880px">{rows([(x['t'],x['city'],x['desc']) for x in w],240)}{box(d['alert_label'],d['alert']) if d.get('alert') else ''}</div>"""+foot()
s2=head(2,'W drodze','DROGI · LOTNISKO · PALIWO',d['photos'][1],d.get('pos1','center'))+f"""<div style="position:absolute;left:70px;right:70px;top:880px">{rows(d['road'],270)}</div>"""+foot()
s3=head(3,'Dziś<br>i jutro','CO SIĘ DZIEJE',d['photos'][2],d.get('pos2','center'))+f"""<div style="position:absolute;left:70px;right:70px;top:880px">{rows(d['events'],230)}{box('MASZ PYTANIE?','Napisz do nas – odpowiemy w serii „Pytasz – odpowiadamy”') if d.get('ask',True) else ''}</div>"""+foot()
for i,s in enumerate([s1,s2,s3],1): open(f'html/story-{i}.html','w').write(page(s))
print('ok')
