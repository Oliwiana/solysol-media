exec(open('/home/claude/social/posty10/gen.py').read().split("P={}")[0])
import json
CR={c['file']:c['user'] for c in json.load(open('/home/claude/photos_raw/credits.json'))}
DARK='#2B2926'
P={}
def mast(n,tot,fg=IV,line='rgba(246,241,232,.35)',acc=ORL):
    return (f'<div style="position:absolute;left:70px;right:70px;top:56px;display:flex;justify-content:space-between;align-items:center;padding-bottom:18px;border-bottom:1.5px solid {line};color:{fg}">'
      f'<div style="{CG}font-size:34px;font-weight:500;letter-spacing:.06em">S<span style="display:inline-block;width:22px;height:22px;border-radius:50%;background:{acc};margin:0 2px"></span>L <i style="color:{acc}">y</i> SÓL</div>'
      f'<div style="font-size:19px;font-weight:600;letter-spacing:.2em">WIADOMOŚCI · 16.11.2026</div>'
      f'<div style="font-size:19px;font-weight:600;letter-spacing:.14em;opacity:.75">{n}/{tot}</div></div>')
def tag(t,bg=ORG,fg='#fff'):
    return f'<span style="display:inline-block;background:{bg};color:{fg};font-size:21px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;padding:10px 18px">{t}</span>'
def foot(txt,fg=IV,line='rgba(246,241,232,.3)'):
    return (f'<div style="position:absolute;left:70px;right:70px;bottom:52px;display:flex;justify-content:space-between;align-items:center;border-top:1.5px solid {line};padding-top:20px;color:{fg};font-size:20px;letter-spacing:.12em;font-weight:600">'
            f'<span style="opacity:.75">{txt}</span><span>SOLYSOL.PL</span></div>')
def cover(key,photo,pos,desk,head,deck):
    P[key+'-1']=page(f'''<img src="file:///home/claude/photos_raw/{photo}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:{pos}">
<div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(23,21,19,.78) 0%,rgba(23,21,19,.1) 22%,rgba(23,21,19,.25) 42%,rgba(23,21,19,.92) 66%,{INK} 82%)"></div>
{mast(1,3)}
<div style="position:absolute;left:70px;right:70px;top:690px">{tag(desk)}
<div style="{CG}font-size:98px;font-weight:500;line-height:.98;margin-top:26px;letter-spacing:-.005em">{head}</div>
<div style="font-size:32px;line-height:1.42;margin-top:24px;color:#E6DED1">{deck}</div></div>
<div style="position:absolute;right:70px;top:640px;font-size:16px;letter-spacing:.06em;color:rgba(246,241,232,.7)">{('Fot. '+CR[photo]+' / Unsplash') if photo in CR else 'Il. Redakcja Sol y Sól'}</div>
{foot('PRZESUŃ, BY PRZECZYTAĆ  →')}''')
def facts(key,title,pts,note):
    ph=''.join(f'''<div style="display:grid;grid-template-columns:250px 1fr;gap:30px;padding:30px 0;border-top:1.5px solid #D9CFBF;align-items:start">
<div><div style="{CG}font-size:{70 if len(a)<7 else 54}px;font-weight:600;color:{ORG};line-height:.95">{a}</div></div>
<div><div style="font-size:31px;font-weight:600;line-height:1.25">{b}</div><div style="font-size:25px;line-height:1.4;color:#5A534A;margin-top:8px">{c}</div></div></div>''' for a,b,c in pts)
    P[key+'-2']=page(f'''{mast(2,3,INK,'#CEC6B9',ORG)}
<div style="position:absolute;left:70px;right:70px;top:170px">{kick("Najważniejsze",ORG)}
<div style="{CG}font-size:76px;font-weight:500;line-height:1;margin-top:20px">{title}</div>
<div style="margin-top:34px;border-bottom:1.5px solid #D9CFBF">{ph}</div>
<div style="font-size:23px;line-height:1.45;color:#5A534A;margin-top:26px;font-style:italic">{note}</div></div>
{foot('ZAPISZ  🔖  ·  UDOSTĘPNIJ',INK,'#CEC6B9')}''',IV,INK)
def advice(key,title,steps,src):
    sh=''.join(f'<div style="display:flex;gap:26px;padding:22px 0;border-top:1.5px solid rgba(246,241,232,.18)"><span style="flex:none;width:52px;height:52px;border:2px solid {ORL};border-radius:50%;display:flex;align-items:center;justify-content:center;{CG}font-size:30px;color:{ORL}">{i+1}</span><span style="font-size:30px;line-height:1.4">{s}</span></div>' for i,s in enumerate(steps))
    P[key+'-3']=page(f'''{mast(3,3)}
<div style="position:absolute;left:70px;right:70px;top:170px">{kick("Co to znaczy dla Ciebie")}
<div style="{CG}font-size:76px;font-weight:500;line-height:1;margin-top:20px">{title}</div>
<div style="margin-top:34px">{sh}</div></div>
<div style="position:absolute;left:70px;right:70px;bottom:150px;background:{DARK};padding:28px 32px;display:flex;justify-content:space-between;gap:30px;align-items:center">
<div style="font-size:21px;line-height:1.5;color:#B9B0A3"><b style="color:{IV};letter-spacing:.14em;font-size:18px">ŹRÓDŁA</b><br>{src}</div>
<div style="flex:none;text-align:right;{CG}font-size:30px;line-height:1.15"><i style="color:{ORL}">Redakcja</i><br>Sol y Sól</div></div>
{foot('OBSERWUJ – BĄDŹ NA BIEŻĄCO')}''')

cover('n1','mlg5.jpg','50% 40%','Málaga · Motoryzacja','Mandat za strefę ZBE? <i style="color:#E0874F">Pieniądze wrócą</i>','Sąd uznał strefę niskiej emisji w Maladze za dyskryminującą. Ratusz przestał wystawiać mandaty i odda pieniądze.')
facts('n1','Ile, kiedy i jak',[('~100 €','zwrot za każdy opłacony mandat','automatycznie – nie trzeba składać wniosku'),('Gestrisam','podaj numer konta','w e-urzędzie (sede electrónica) miasta Málaga'),('koniec XI','start wypłat','miasto uprzedza: całość może potrwać nawet kilka lat'),('30.11','zakaz dla aut z etykietą B – odwołany','w obecnej formie przepisy nie wejdą w życie')],'Ok. 46 500 mandatów, z czego 13 700 już opłaconych – łącznie ok. 1,38 mln € do zwrotu.')
advice('n1','Dostałeś mandat? Zrób to teraz',['Sprawdź, czy mandat był za wjazd do ZBE (cámara, „Zona de Bajas Emisiones”).','Zapłaciłeś? Dodaj numer konta w Gestrisam – resztę miasto zrobi samo.','Nie zapłaciłeś? Takie mandaty są na razie zawieszone – status sprawdzisz w e-urzędzie miasta.','Ratusz pisze nowe przepisy – strefa może wrócić. Będziemy informować.'],'Motor16, Motorpasión (20–22.10.2026), TSJA Andalucía')

cover('n2','mtn1.jpg','50% 55%','Prawo · Na drodze','Klapki na skuterze? <i style="color:#E0874F">200&nbsp;€ mandatu</i>','Od 1 października w Hiszpanii obowiązują nowe przepisy ruchu drogowego. Część rzeczy, które wszyscy robili latem, kosztuje teraz sporo.')
facts('n2','Co się zmieniło',[('200 €','klapki i sandały na motocyklu lub skuterze','tylko pełne obuwie; poza miastem także rękawice'),('200 €','rower poza miastem bez kasku','obowiązek dla wszystkich, w każdym wieku'),('15 lat','minimalny wiek na hulajnodze elektrycznej','po zmroku: kamizelka odblaskowa i kask'),('80 €','brak światła V-16 w aucie','obowiązuje od stycznia 2026 zamiast trójkątów')],'Nowe są też zasady wyprzedzania rowerzystów (większy odstęp, niższa prędkość) i jazdy po śniegu na autostradach.')
advice('n2','Zanim wsiądziesz',['Wypożyczasz skuter? Weź zakryte buty – w klapkach ryzykujesz 200 €.','Rower na trasie poza miastem – zawsze w kasku, także dorośli.','Dziecko poniżej 15 lat nie może jeździć hulajnogą elektryczną.','Sprawdź, czy masz w aucie homologowane światło V-16.'],'DGT, Reglamento General de Circulación, Interia, Motor16')

cover('n3','mlg3.jpg','50% 50%','Nieruchomości · Málaga','Málaga zamraża <i style="color:#E0874F">nowy najem turystyczny</i>','Od 25 lipca w stolicy Costa del Sol nie dostaniesz nowej licencji na mieszkanie turystyczne. Na co uważać przy zakupie.')
facts('n3','Co obowiązuje',[('3 lata','wstrzymanie nowych licencji VUT','może skończyć się wcześniej, jeśli miasto zmieni plan'),('OK','istniejące licencje działają dalej','wnioski złożone przed 24.07 – po staremu'),('Manilva','własne 3-letnie wstrzymanie','nowe licencje turystyczne też zamrożone'),('Fuengirola','ograniczenia dla mieszkań','bez osobnego wejścia z ulicy')],'Niezależnie od miasta, wspólnota mieszkaniowa może zakazać najmu krótkoterminowego w swoim statucie.')
advice('n3','Kupujesz pod wynajem?',['Poproś o numer licencji turystycznej i sprawdź go w rejestrze Junta de Andalucía.','Przeczytaj statut wspólnoty (estatutos) – czy nie zakazuje najmu.','W Maladze bez ważnej licencji licz tylko na najem długoterminowy.','Zapytaj prawnika, zanim podpiszesz umowę rezerwacyjną.'],'BOP Málaga 24.07.2026, Ayuntamiento de Málaga, Euro Weekly News')

cover('n4','invoice.jpg','50% 18%','Dla firm · Podatki','VeriFactu <i style="color:#E0874F">znowu przesunięte?</i>','Hacienda zapowiedziała kolejne opóźnienie systemu faktur. Ale dopóki nie ma tego w BOE, obowiązują stare terminy.')
facts('n4','Terminy',[('1.01.2027','spółki (SL)','data wciąż obowiązująca w BOE'),('1.07.2027','autónomos','data wciąż obowiązująca w BOE'),('X 2028','zapowiedź Hacienda (5.10.2026)','czeka na publikację w BOE'),('0','faktur do kasowania','w VeriFactu faktury nie da się usunąć ani zmienić')],'VeriFactu wymaga certyfikowanego programu do fakturowania, który zabezpiecza każdą fakturę przed zmianą (w trybie VeriFactu wysyła ją też od razu do Agencji Podatkowej).')
advice('n4','Prowadzisz firmę? Plan na teraz',['Zapytaj gestora, czy Twój program jest zgodny z VeriFactu.','Wystawiasz faktury w Wordzie lub Excelu? Czas to zmienić.','Nie czekaj na nowy termin – może nie zostać opublikowany.','Obserwuj nas – napiszemy, gdy zmiana trafi do BOE.'],'AEAT, Infoautónomos (7.10.2026), Emprendedores')
for k,v in P.items(): open(k+'.html','w').write(v)
print(len(P))
