exec(open('gen.py').read().split("cover('n1'")[0])
P.clear()
def mastN(n,tot,fg=IV,line='rgba(246,241,232,.35)',acc=ORL):
    return mast(n,tot,fg,line,acc).replace('WIADOMOŚCI · 16.11.2026','NARZEKALNIA · ODC. 1')
P['nz-1']=page(f'''<img src="file:///home/claude/photos_raw/pueblo1.jpg" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 40%">
<div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(23,21,19,.7) 0%,rgba(23,21,19,.05) 22%,rgba(23,21,19,.2) 42%,rgba(23,21,19,.9) 64%,{INK} 80%)"></div>
{mastN(1,3)}
<div style="position:absolute;left:70px;right:70px;top:700px">{tag('Narzekalnia · Felieton')}
<div style="{CG}font-size:110px;font-weight:500;line-height:.96;margin-top:26px">Kochamy słońce, <i style="color:#E0874F">ale…</i></div>
<div style="font-size:32px;line-height:1.42;margin-top:24px;color:#E6DED1">Mieszkamy w raju. Ale nawet w raju są rzeczy, które doprowadzają do szału. Sprawdźmy, co wkurza Was najbardziej.</div></div>
<div style="position:absolute;right:70px;top:650px;font-size:16px;letter-spacing:.06em;color:rgba(246,241,232,.7)">Fot. {CR.get('pueblo1.jpg','')} / Unsplash</div>
{foot('PRZESUŃ I ZAGŁOSUJ  →')}''')
opts=[('Cita previa','na wszystko trzeba się umówić – nawet na umówienie się'),('„Mañana”','fachowiec miał być wczoraj. I przedwczoraj.'),('Papierologia','NIE, padrón, certyfikaty – w trzech kopiach'),('Fiesta u sąsiadów','do 3 w nocy, w środę'),('Ceny w Marbelli','w sezonie kawa jak w Monako'),('Ronda','i kierowcy, którzy nie znają kierunkowskazów')]
oh=''.join(f'<div style="display:flex;gap:28px;align-items:center;padding:20px 0;border-top:1.5px solid #D9CFBF"><span style="width:62px;height:62px;border-radius:50%;background:{ORG};color:#fff;display:flex;align-items:center;justify-content:center;font-size:29px;font-weight:700;flex:none">{"ABCDEF"[i]}</span><div><div style="font-size:33px;font-weight:600">{a}</div><div style="font-size:25px;color:#5A534A;margin-top:4px">{b}</div></div></div>' for i,(a,b) in enumerate(opts))
P['nz-2']=page(f'''{mastN(2,3,INK,'#CEC6B9',ORG)}
<div style="position:absolute;left:70px;right:70px;top:170px">{kick("Głosowanie",ORG)}
<div style="{CG}font-size:80px;font-weight:500;line-height:1;margin-top:20px">Co Cię najbardziej <i style="color:{ORG}">wkurza</i> w Hiszpanii?</div>
<div style="margin-top:30px;border-bottom:1.5px solid #D9CFBF">{oh}</div>
<div style="font-size:28px;margin-top:26px">Napisz literę w komentarzu. <b>Wyniki – w magazynie Nr 2.</b></div></div>
{foot('KOMENTUJ  💬  ·  OZNACZ ZNAJOMYCH',INK,'#CEC6B9')}''',IV,INK)
votes=[('B','„Mañana”','Hydraulik umówiony na wtorek. Nie powiedział, w który.'),('A','Cita previa','Żeby umówić się na wizytę, trzeba najpierw umówić się na umówienie.'),('E','Ceny w Marbelli','Kawa na Puerto Banús kosztuje tyle, co obiad w Polsce.')]
vh=''.join(f'<div style="display:grid;grid-template-columns:90px 1fr;gap:24px;padding:26px 0;border-top:1.5px solid rgba(246,241,232,.18)"><span style="{CG}font-size:84px;color:{ORL};line-height:.85">{l}</span><div><div style="font-size:31px;font-weight:600">{t}</div><div style="{CG}font-size:34px;font-style:italic;line-height:1.25;margin-top:8px;color:#E6DED1">„{q}”</div></div></div>' for l,t,q in votes)
P['nz-3']=page(f'''{mastN(3,3)}
<div style="position:absolute;left:70px;right:70px;top:170px">{kick("Redakcja głosuje pierwsza")}
<div style="{CG}font-size:80px;font-weight:500;line-height:1;margin-top:20px">Nasze typy <i style="color:{ORL}">z redakcji</i></div>
<div style="margin-top:34px">{vh}</div></div>
<div style="position:absolute;left:70px;right:70px;bottom:150px;background:{ORG};padding:30px 34px;display:flex;justify-content:space-between;align-items:center">
<div style="font-size:30px;line-height:1.35;color:#fff;font-weight:600">A Ty? Zostaw literę w komentarzu 👇<br><span style="font-weight:400;font-size:24px">Najzabawniejsze odpowiedzi opublikujemy w Nr 2.</span></div></div>
{foot('OBSERWUJ – CO TYDZIEŃ NOWA NARZEKALNIA')}''')
for k,v in P.items(): open(k+'.html','w').write(v)
