# python3 gen_reel.py reel.json out.mp4   -> 1080x1920 reel "Przegląd dnia"
import json,sys,os,subprocess,shutil
exec(open('/home/claude/social/posty10/gen.py').read().split("P={}")[0])
import json as _j
CR={c['file']:c['user'] for c in _j.load(open('/home/claude/photos_raw/credits.json'))}
F2='/home/claude/tools/node_modules/@fontsource/'
FX=''.join(f"@font-face{{font-family:Anton;src:url(file://{F2}anton/files/anton-{s}-400-normal.woff2)}}" for s in ('latin','latin-ext'))+''.join(f"@font-face{{font-family:Oswald;font-weight:{w};src:url(file://{F2}oswald/files/oswald-{s}-{w}-normal.woff2)}}" for w in (500,600,700) for s in ('latin','latin-ext'))
AN="font-family:Anton,Impact,sans-serif;"; OS="font-family:Oswald,'Arial Narrow',sans-serif;"
def pg(inner,bg=INK):
    return f'''<!doctype html><html><head><meta charset=utf-8><style>{ff}{FX}*{{box-sizing:border-box;margin:0}}body{{width:1080px;height:1920px;overflow:hidden;font-family:Inter,sans-serif}}</style></head><body><div style="position:relative;width:1080px;height:1920px;background:{bg};color:{IV};overflow:hidden">{inner}</div></body></html>'''
LOGO=f'<span style="{CG}font-weight:500;letter-spacing:.06em">S<span style="display:inline-block;width:.62em;height:.62em;border-radius:50%;background:{ORL};margin:0 .03em;vertical-align:-.02em"></span>L <i style="color:{ORL}">y</i> SÓL</span>'
def photo(p,pos='50% 50%',dark=.55):
    return f'<img src="file:///home/claude/photos_raw/{p}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:{pos}"><div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(20,18,16,.75) 0%,rgba(20,18,16,{dark-.3}) 30%,rgba(20,18,16,{dark}) 55%,rgba(20,18,16,.97) 85%)"></div>'
def top(n,tot,date):
    return f'<div style="position:absolute;left:70px;right:70px;top:120px;display:flex;justify-content:space-between;align-items:center;font-size:44px">{LOGO}<span style="{OS}font-size:26px;font-weight:600;letter-spacing:.18em;color:#CBBFAE">{n}/{tot}</span></div>'
d=json.load(open(sys.argv[1])); out=sys.argv[2]; date=d['date']; items=d.get('items',[])
frames=[]
quiet=d.get('quiet',False)
tot=len(items)+2
# intro
intro_title='Dziś na wybrzeżu<br><i style="color:#E0874F">było cicho</i>' if quiet else 'Przegląd<br><i style="color:#E0874F">dnia</i>'
intro_sub=d.get('intro_sub', 'Żadnych wielkich wiadomości – za to mamy dla Was coś ciekawego 👇' if quiet else f'{len(items)} rzeczy, które warto wiedzieć dziś na Costa del Sol')
frames.append(pg(f'''{photo(d.get('intro_photo','sun0.jpg'),'50% 50%',.5)}{top(1,tot,date)}
<div style="position:absolute;left:70px;right:70px;top:760px"><div style="background:{ORL};display:inline-block;padding:10px 26px 2px;{AN}font-size:54px;color:{INK}">{d.get('kicker','COSTA DEL SOL · '+date)}</div>
<div style="{CG}font-size:190px;font-weight:500;line-height:.92;margin-top:34px">{intro_title}</div>
<div style="{OS}font-size:46px;font-weight:500;line-height:1.3;margin-top:40px;color:#E6DED1">{intro_sub}</div></div>'''))
for i,it in enumerate(items):
    cred=('Fot. '+CR[it['photo']]+' / Unsplash') if it['photo'] in CR else ''
    frames.append(pg(f'''{photo(it['photo'],it.get('pos','50% 50%'),.72)}{top(i+2,tot,date)}
<div style="position:absolute;right:70px;top:200px;font-size:20px;color:rgba(246,241,232,.7)">{cred}</div>
<div style="position:absolute;left:70px;right:70px;top:{it.get('y',1130)}px">
<div style="display:flex;align-items:center;gap:22px"><span style="{AN}font-size:150px;color:{ORL};line-height:.8">{it.get('num',str(i+1))}</span><span style="{OS}font-size:34px;font-weight:700;letter-spacing:.18em;color:{ORL};text-transform:uppercase">{it['tag']}</span></div>
<div style="{CG}font-size:{it.get('size',104)}px;font-weight:500;line-height:1;margin-top:30px">{it['title']}</div>
<div style="font-size:44px;line-height:1.38;margin-top:34px;color:#E6DED1">{it['line']}</div></div>'''))
frames.append(pg(f'''<div style="position:absolute;inset:0;background:{ORL}"></div>
<div style="position:absolute;left:0;right:0;top:640px;text-align:center;color:{INK}"><div style="font-size:150px">{LOGO.replace(f'background:{ORL}',f'background:{INK}').replace(f'color:{ORL}',f'color:{IV}')}</div>
<div style="{OS}font-size:50px;font-weight:600;margin-top:60px;line-height:1.3">{d.get('outro','Całe wiadomości na<br>solysol.pl')}</div>
<div style="{AN}font-size:84px;margin-top:70px;letter-spacing:.02em">OBSERWUJ, BY BYĆ NA BIEŻĄCO</div>
<div style="{OS}font-size:36px;font-weight:500;margin-top:40px;opacity:.8">Costa del Sol po polsku · codziennie</div></div>''',ORL))
os.makedirs('fr',exist_ok=True)
for f in os.listdir('fr'): os.remove('fr/'+f)
for i,h in enumerate(frames): open(f'fr/{i:02d}.html','w').write(h)
js="""const p=require('/home/claude/tools/node_modules/puppeteer-core');const fs=require('fs');(async()=>{const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files']});const pg=await b.newPage();await pg.setViewport({width:1080,height:1920});for(const f of fs.readdirSync('fr').filter(x=>x.endsWith('.html')).sort()){await pg.goto('file://'+process.cwd()+'/fr/'+f,{waitUntil:'load'});await pg.evaluate(()=>document.fonts.ready);await new Promise(r=>setTimeout(r,200));await pg.screenshot({path:'fr/'+f.replace('.html','.png')});}await b.close()})();"""
open('shotr.js','w').write(js); subprocess.run(['node','shotr.js'],check=True)
pngs=sorted(x for x in os.listdir('fr') if x.endswith('.png'))
dur=[3.2]+[d.get('item_sec',4.2)]*len(items)+[2.8]; X=0.45
args=['ffmpeg','-y','-loglevel','error']
for i,pth in enumerate(pngs): args+=['-loop','1','-framerate','30','-t',str(dur[i]+X),'-i','fr/'+pth]
fc=[];
for i in range(len(pngs)):
    fr=int((dur[i]+X)*30)
    fc.append(f"[{i}:v]scale=1188:2112,zoompan=z='1+0.0005*on':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=1080x1920:fps=30,setsar=1,format=yuv420p[v{i}]")
prev='v0'; off=0
for i in range(1,len(pngs)):
    off+=dur[i-1]; fc.append(f"[{prev}][v{i}]xfade=transition=slideleft:duration={X}:offset={off:.2f}[x{i}]"); prev=f'x{i}'
args+=['-filter_complex',';'.join(fc),'-map',f'[{prev}]','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',out]
subprocess.run(args,check=True)
shutil.copy('fr/00.png',out.replace('.mp4','-okladka.png'))
print('ok',out)
