src=open('/home/claude/social/news2/gen.py').read()
pre,calls=src.split("cover('n1'",1); calls="cover('n1'"+calls.split("for k,v in P.items()")[0]
exec(pre)
D={}
def cover(k,photo,pos,desk,head,deck): D.setdefault(k,{}).update(photo=photo,pos=pos,desk=desk,head=head,deck=deck)
def facts(k,title,pts,note): D[k].update(pts=pts,note=note)
def advice(k,title,steps,src): D[k].update(atitle=title,steps=steps,src=src)
exec(calls)
D['nz']=dict(photo='pueblo1.jpg',pos='50% 40%',desk='Narzekalnia · Odc. 1',head='Co Cię najbardziej <i style="color:#E0874F">wkurza</i> w Hiszpanii?',deck='')
P={}
def fbhead(d,h=520):
    return f'''<div style="position:absolute;left:0;right:0;top:0;height:{h}px;overflow:hidden"><img src="file:///home/claude/photos_raw/{d['photo']}" style="width:100%;height:100%;object-fit:cover;object-position:{d['pos']}">
<div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(23,21,19,.75) 0%,rgba(23,21,19,.15) 30%,rgba(23,21,19,.55) 62%,rgba(23,21,19,.96) 100%)"></div></div>
<div style="position:absolute;left:64px;right:64px;top:48px;display:flex;justify-content:space-between;align-items:center;color:{IV}">
<div style="{CG}font-size:34px;font-weight:500;letter-spacing:.06em">S<span style="display:inline-block;width:22px;height:22px;border-radius:50%;background:{ORL};margin:0 2px"></span>L <i style="color:{ORL}">y</i> SÓL</div>
<div style="font-size:18px;font-weight:600;letter-spacing:.2em">{'NARZEKALNIA' if d['desk'].startswith('Narz') else 'WIADOMOŚCI'} · 16.11.2026</div></div>
<div style="position:absolute;left:64px;right:64px;top:{h-250}px;color:{IV}">{tag(d['desk'])}
<div style="{CG}font-size:76px;font-weight:500;line-height:.98;margin-top:18px">{d['head']}</div></div>
<div style="position:absolute;right:64px;top:{h-34}px;font-size:14px;color:rgba(246,241,232,.6)">{('Fot. '+CR[d['photo']]+' / Unsplash') if d['photo'] in CR else 'Il. Redakcja Sol y Sól'}</div>'''
def fbfoot():
    return (f'<div style="position:absolute;left:64px;right:64px;bottom:40px;display:flex;justify-content:space-between;align-items:center;border-top:1.5px solid #CEC6B9;padding-top:16px;font-size:19px;letter-spacing:.12em;font-weight:600;color:{INK}">'
            f'<span style="opacity:.75">REDAKCJA SOL Y SÓL</span><span>SOLYSOL.PL</span></div>')
for k in ['n1','n2','n3','n4']:
    d=D[k]
    ph=''.join(f'<div style="display:grid;grid-template-columns:190px 1fr;gap:22px;padding:22px 0;border-top:1.5px solid #D9CFBF;align-items:center"><span style="{CG}font-size:{48 if len(a)<7 else 38}px;font-weight:600;color:{ORG};line-height:1">{a}</span><div><div style="font-size:25px;font-weight:600;line-height:1.2">{b}</div><div style="font-size:20px;color:#5A534A;margin-top:3px">{c}</div></div></div>' for a,b,c in d['pts'])
    st=''.join(f'<div style="display:flex;gap:14px;font-size:21px;line-height:1.35;padding:5px 0"><span style="color:{ORL};{CG}font-size:26px;flex:none;width:20px">{i+1}</span><span>{s}</span></div>' for i,s in enumerate(d['steps'][:3]))
    P[k]=page(f'''{fbhead(d)}
<div style="position:absolute;left:64px;right:64px;top:552px"><div style="border-bottom:1.5px solid #D9CFBF">{ph}</div></div>
<div style="position:absolute;left:64px;right:64px;bottom:104px;background:{INK};color:{IV};padding:22px 28px">
<div style="font-size:16px;font-weight:700;letter-spacing:.18em;color:{ORL};margin-bottom:6px">CO ZROBIĆ</div>{st}</div>
{fbfoot()}''',IV,INK)
# Narzekalnia FB
d=D['nz']
opts=[('Cita previa','nawet na umówienie się'),('„Mañana”','fachowiec miał być wczoraj'),('Papierologia','NIE, padrón, certyfikaty'),('Fiesta u sąsiadów','do 3 w nocy, w środę'),('Ceny w Marbelli','kawa jak w Monako'),('Ronda','kierunkowskaz? co to?')]
oh=''.join(f'<div style="display:flex;gap:18px;align-items:center;padding:24px 0;border-top:1.5px solid #D9CFBF"><span style="width:50px;height:50px;border-radius:50%;background:{ORG};color:#fff;display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:700;flex:none">{"ABCDEF"[i]}</span><div><div style="font-size:26px;font-weight:600">{a}</div><div style="font-size:19px;color:#5A534A">{b}</div></div></div>' for i,(a,b) in enumerate(opts))
c1,c2=oh.split('</div></div></div>')[:3],None
items=[x+'</div></div></div>' for x in oh.split('</div></div></div>') if x]
P['nz']=page(f'''{fbhead(d)}
<div style="position:absolute;left:64px;right:64px;top:552px;display:grid;grid-template-columns:1fr 1fr;column-gap:40px"><div>{''.join(items[:3])}</div><div>{''.join(items[3:])}</div></div>
<div style="position:absolute;left:64px;right:64px;bottom:104px;background:{INK};color:{IV};padding:24px 28px;display:flex;gap:26px;align-items:center">
<span style="{CG}font-size:90px;color:{ORL};line-height:.8">B</span><div><div style="font-size:16px;font-weight:700;letter-spacing:.18em;color:{ORL}">REDAKCJA GŁOSUJE</div><div style="{CG}font-size:32px;font-style:italic;line-height:1.2;margin-top:6px">„Hydraulik umówiony na wtorek. Nie powiedział, w który.”</div></div></div>
<div style="position:absolute;left:64px;right:64px;bottom:262px;font-size:25px;text-align:center">Napisz literę w komentarzu 👇 <b>Najzabawniejsze odpowiedzi – w Nr 2</b></div>
{fbfoot()}''',IV,INK)
for k,v in P.items(): open('fb-'+k+'.html','w').write(v)
