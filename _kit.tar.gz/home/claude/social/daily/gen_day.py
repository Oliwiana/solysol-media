# usage: python3 gen_day.py data.json  -> renders IG 3 slides + FB single into out/<id>/
import json,sys,os,subprocess
exec(open('/home/claude/social/news2/gen.py').read().split("cover('n1'")[0])
CR['ban2_bwf.jpg']=CR.get('ban2.jpg','')
DATE=sys.argv[2] if len(sys.argv)>2 else '16.11.2026'
src=open('/home/claude/social/news2/gen.py').read()
for a,b in [("WIADOMOŚCI · 16.11.2026","WIADOMOŚCI · '+DATE+'")]: pass

F2='/home/claude/tools/node_modules/@fontsource/'
FX=''.join(f"@font-face{{font-family:Anton;src:url(file://{F2}anton/files/anton-{sub}-400-normal.woff2)}}" for sub in ('latin','latin-ext'))+''.join(f"@font-face{{font-family:Oswald;font-weight:{w};src:url(file://{F2}oswald/files/oswald-{sub}-{w}-normal.woff2)}}" for w in (500,600,700) for sub in ('latin','latin-ext'))
AN="font-family:Anton,Impact,sans-serif;letter-spacing:.01em;"
OS="font-family:Oswald,'Arial Narrow',sans-serif;"
def okladka(d,date):
    photo=d['photo']; cred=(d['credit'] if d.get('credit') else ((CR[photo] if CR.get(photo,'').startswith('Fot.') else 'Fot. '+CR[photo]+' / Unsplash') if photo in CR else 'Il. Redakcja Sol y Sól'))
    h=f"""<div style="position:absolute;inset:0;background:#141210"></div>
<div style="position:absolute;left:40px;right:40px;top:34px;height:54px;background:#F3EFE8;display:flex;align-items:center;justify-content:space-between;padding:0 20px;{OS}color:#141210">
<span style="font-size:19px;font-weight:700;letter-spacing:.12em;color:#C8692E">{d.get('strip_tag','DZIŚ')} ▸</span><span style="font-size:25px;font-weight:600;text-transform:uppercase">{d.get('strip','')}</span><span style="font-size:19px;font-weight:700;letter-spacing:.12em">1/3</span></div>
<div style="position:absolute;left:40px;right:40px;top:104px;display:flex;justify-content:space-between;{OS}font-size:18px;font-weight:500;letter-spacing:.2em;color:#CBBFAE"><span><b style="color:#E0874F">{d.get('mast','WIADOMOŚCI')}</b> · {date}</span><span>COSTA DEL SOL PO POLSKU</span></div>
<div style="position:absolute;left:40px;right:40px;top:138px;height:1px;background:rgba(243,239,232,.35)"></div>
<div style="position:absolute;left:0;right:0;top:146px;text-align:center;color:#F3EFE8;{CG}font-size:190px;font-weight:500;line-height:1;letter-spacing:.03em;white-space:nowrap">S<span style="display:inline-block;width:124px;height:124px;border-radius:50%;background:#E0874F;vertical-align:-2px;margin:0 4px"></span>L <i style="color:#E0874F;font-size:134px">y</i> SÓL</div>
<div style="position:absolute;left:40px;right:40px;top:356px;height:1px;background:rgba(243,239,232,.35)"></div>
<div style="position:absolute;left:40px;right:40px;top:372px;bottom:150px;overflow:hidden"><img src="file:///home/claude/photos_raw/{photo}" style="width:100%;height:100%;object-fit:cover;object-position:{d['pos']};filter:contrast(1.1) brightness(.9)"></div>
<div style="position:absolute;left:40px;right:40px;top:372px;bottom:150px;background:linear-gradient(180deg,rgba(20,18,16,.6) 0%,rgba(20,18,16,.05) 30%,rgba(20,18,16,.2) 52%,rgba(20,18,16,.96) 100%)"></div>
<div style="position:absolute;left:66px;top:398px">{tag(d['desk'])}</div>
<div style="position:absolute;right:66px;top:398px;font-size:15px;color:rgba(243,239,232,.75)">{cred}</div>
<div style="position:absolute;left:70px;right:70px;top:690px;color:#fff;{CG}font-size:76px;font-style:italic;font-weight:500;line-height:1;text-shadow:0 2px 14px rgba(0,0,0,.6)">{d.get('over','')}</div>
<div style="position:absolute;left:40px;top:790px;background:#E0874F;padding:10px 30px 0;{AN}font-size:{d.get('blocksize',150)}px;line-height:1;color:#141210;box-shadow:0 10px 30px rgba(0,0,0,.35);white-space:nowrap">{d['block']}</div>
<div style="position:absolute;left:70px;right:70px;top:{790+d.get('blocksize',150)+40}px;{OS}font-size:32px;font-weight:600;line-height:1.25;color:#fff;text-shadow:0 1px 6px rgba(0,0,0,.7)">{d.get('under','')}</div>
<div style="position:absolute;left:40px;right:40px;bottom:52px;display:flex;justify-content:space-between;align-items:center;border-top:1.5px solid rgba(243,239,232,.3);padding-top:20px;color:#F3EFE8;font-size:20px;letter-spacing:.12em;font-weight:600"><span style="opacity:.75">PRZESUŃ, BY PRZECZYTAĆ  →</span><span>SOLYSOL.PL</span></div>"""
    return page(h).replace('<style>','<style>'+FX,1)


FI=''.join(f"@font-face{{font-family:InterX;font-style:italic;font-weight:{w};src:url(file://{F2}inter/files/inter-{sub}-{w}-italic.woff2)}}" for w in (800,900) for sub in ('latin','latin-ext'))
PK='#FF4FA3'; LM='#C8F25A'
def pop(d,date):
    photo=d['photo']; cred=d.get('credit','')
    bgimg=f'<img src="file:///home/claude/photos_raw/{photo}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:{d["pos"]};filter:grayscale(1) contrast(1.1);opacity:.22">'
    if d.get('stk'):
        L,T,W=d.get('stkbox',[420,470,620])
        art=f'<img src="file:///home/claude/social/daily/stk/{d["stk"]}" style="position:absolute;left:{L}px;top:{T}px;width:{W}px;transform:rotate({d.get("rot",3)}deg);filter:drop-shadow(0 18px 30px rgba(0,0,0,.55))">'
    else:
        L,T,W,H=d.get('cardbox',[400,520,600,640])
        art=(f'<div style="position:absolute;left:{L}px;top:{T}px;width:{W}px;height:{H}px;transform:rotate({d.get("rot",4)}deg);border-radius:34px;background:{LM};padding:14px;box-shadow:0 22px 40px rgba(0,0,0,.55)">'
             f'<div style="width:100%;height:100%;border-radius:24px;background:{PK};padding:8px"><img src="file:///home/claude/photos_raw/{photo}" style="width:100%;height:100%;object-fit:cover;object-position:{d.get("cardpos",d["pos"])};border-radius:18px;display:block"></div></div>')
    h=f"""{bgimg}
<div style="position:absolute;inset:0;background:radial-gradient(120% 70% at 80% 100%,rgba(224,135,79,.35) 0%,rgba(23,21,19,0) 55%),linear-gradient(180deg,rgba(23,21,19,.92) 0%,rgba(23,21,19,.55) 45%,rgba(23,21,19,.85) 100%)"></div>
{mast(1,3)}
<div style="position:absolute;left:66px;top:168px;transform:rotate(-3deg);background:{LM};color:#171513;font-family:InterX;font-style:italic;font-weight:900;font-size:30px;letter-spacing:.02em;padding:10px 22px;border-radius:12px;box-shadow:6px 6px 0 {PK}">{d.get('stamp','CZY WIESZ, ŻE…')}</div>
<div style="position:absolute;left:70px;right:70px;top:250px;{CG}font-size:{d.get('hsize',104)}px;font-weight:600;line-height:.95;letter-spacing:-.01em;color:#F6F1E8">{d['head']}</div>
<div style="position:absolute;left:72px;right:90px;top:{d.get('ptop',490)}px;font-family:InterX;font-style:italic;font-weight:900;font-size:{d.get('psize',46)}px;line-height:1.08;color:#F6F1E8;text-shadow:0 2px 12px rgba(0,0,0,.5)">{d['punch']}</div>
{art}
<div style="position:absolute;left:58px;bottom:160px;width:{d.get('notew',430)}px;transform:rotate(-2deg);background:#F6F1E8;color:#171513;padding:22px 26px;border-radius:6px;box-shadow:0 14px 30px rgba(0,0,0,.45);font-size:25px;line-height:1.38">{d['teaser']}</div>
<div style="position:absolute;right:62px;bottom:150px;width:116px;height:116px;border-radius:50%;background:{PK};display:flex;align-items:center;justify-content:center;color:#fff;font-size:64px;font-weight:700;box-shadow:0 10px 26px rgba(255,79,163,.45)">→</div>
<div style="position:absolute;right:26px;top:560px;transform:rotate(90deg);transform-origin:right top;font-size:14px;letter-spacing:.06em;color:rgba(246,241,232,.6);white-space:nowrap">{cred}</div>
{foot('PRZESUŃ, BY SPRAWDZIĆ  →')}"""
    return page(h).replace('<style>','<style>'+FX+FI,1)

def mix(d,date):
    photo=d['photo']; cred=d.get('credit','')
    h=f"""<img src="file:///home/claude/photos_raw/{photo}" style="position:absolute;left:0;top:0;width:100%;height:{d.get('imgh',1350)}px;object-fit:cover;object-position:{d['pos']};-webkit-mask-image:linear-gradient(180deg,#000 62%,transparent 100%)">
<div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(23,21,19,.78) 0%,rgba(23,21,19,.05) 20%,rgba(23,21,19,.15) 40%,rgba(23,21,19,.92) 62%,#171513 80%)"></div>
{mast(1,3)}
<div style="position:absolute;right:64px;top:170px;width:230px;height:230px;border-radius:50%;background:#E0874F;transform:rotate(9deg);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#171513;box-shadow:0 16px 34px rgba(0,0,0,.45);outline:3px dashed rgba(246,241,232,.9);outline-offset:-16px">
<div style="{AN}font-size:{d.get('bsize',96)}px;line-height:.9">{d['badge'][0]}</div><div style="font-family:InterX;font-style:italic;font-weight:900;font-size:{d.get('b2size',27)}px;line-height:1;text-transform:uppercase;margin-top:6px">{d['badge'][1]}</div><div style="font-size:15px;font-weight:700;letter-spacing:.14em;margin-top:6px">{d['badge'][2]}</div></div>
<div style="position:absolute;right:70px;top:640px;font-size:15px;letter-spacing:.04em;color:rgba(246,241,232,.7)">{cred}</div>
<div style="position:absolute;left:70px;right:70px;top:{d.get('htop',680)}px">{tag(d['desk'])}
<div style="{CG}font-size:{d.get('hsize',100)}px;font-weight:500;line-height:.97;margin-top:24px">{d['head']}</div>
<div style="font-family:InterX;font-style:italic;font-weight:900;font-size:40px;line-height:1.15;margin-top:22px;color:#F6F1E8">{d['punch2']}</div>
<div style="font-size:28px;line-height:1.42;margin-top:18px;color:#E6DED1;max-width:800px">{d['teaser']}</div></div>
<div style="position:absolute;right:66px;bottom:138px;width:100px;height:100px;border-radius:50%;background:#E0874F;display:flex;align-items:center;justify-content:center;color:#171513;font-size:54px;font-weight:700;box-shadow:0 10px 24px rgba(224,135,79,.4)">→</div>
{foot('PRZESUŃ, BY SPRAWDZIĆ  →')}"""
    return page(h).replace('<style>','<style>'+FX+FI,1)

def kolor(d,date):
    bg=d.get('bg','#F6C343'); ink='#171513'
    h=f"""<div style="position:absolute;inset:0;background:{bg}"></div>
<div style="position:absolute;inset:0;background:radial-gradient(60% 40% at 85% 10%,rgba(255,255,255,.35),transparent 70%)"></div>
<div style="position:absolute;inset:0;color:{ink}">{mast(1,3).replace('#F6F1E8',ink).replace('rgba(246,241,232','rgba(23,21,19')}</div>
<div style="position:absolute;left:66px;top:150px;transform:rotate(-3deg);background:{ink};color:{bg};font-family:InterX;font-style:italic;font-weight:900;font-size:28px;padding:10px 22px;border-radius:10px">{d.get('kat','CZY WIESZ, ŻE…')}</div>
<div style="position:absolute;left:66px;right:66px;top:225px;font-family:InterX;font-style:italic;font-weight:900;font-size:{d.get('ksize',150)}px;line-height:.92;letter-spacing:-.03em;text-transform:uppercase;color:{ink}">{d['khead']}</div>
<div style="position:absolute;left:70px;right:70px;top:{d.get('ktop',540)}px;{CG}font-style:italic;font-size:62px;line-height:1;color:{ink}">{d['ksub']}</div>
<div style="position:absolute;left:300px;top:690px;width:700px;height:520px;transform:rotate(4deg);background:#fff;padding:16px 16px 70px;box-shadow:0 24px 50px rgba(0,0,0,.3)">
<img src="file:///home/claude/photos_raw/{d['photo']}" style="width:100%;height:100%;object-fit:cover;object-position:{d['pos']}">
<div style="position:absolute;left:24px;bottom:22px;font-family:InterX;font-style:italic;font-weight:800;font-size:26px;color:{ink}">{d.get('caption','')}</div></div>
<div style="position:absolute;left:60px;top:760px;width:210px;height:210px;border-radius:50%;background:{ink};color:{bg};display:flex;flex-direction:column;align-items:center;justify-content:center;transform:rotate(-8deg)"><div style="{AN}font-size:64px;line-height:.9">{d['badge'][0]}</div><div style="font-family:InterX;font-style:italic;font-weight:900;font-size:22px;text-transform:uppercase">{d['badge'][1]}</div></div>
<div style="position:absolute;left:66px;right:66px;bottom:56px;display:flex;justify-content:space-between;font-size:15px;font-weight:700;letter-spacing:.16em;color:{ink}"><span>PRZESUŃ, BY SPRAWDZIĆ →</span><span>SOLYSOL.PL</span></div>
<div style="position:absolute;right:20px;top:700px;transform:rotate(90deg);transform-origin:right top;font-size:13px;color:rgba(23,21,19,.6);white-space:nowrap">{d.get('credit','')}</div>"""
    return page(h).replace('<style>','<style>'+FX+FI,1)
def kolor2(d,date):
    bg=d.get('bg','#F6C343'); ink='#171513'; ph=d.get('phh',780)
    h=f"""<div style="position:absolute;inset:0;background:{bg}"></div>
<div style="position:absolute;left:0;top:0;width:1080px;height:{ph}px;overflow:hidden"><img src="file:///home/claude/photos_raw/{d['photo']}" style="width:100%;height:100%;object-fit:cover;object-position:{d['pos']}">
<div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.55) 0%,rgba(0,0,0,0) 22%,rgba(0,0,0,0) 70%,rgba(0,0,0,.45) 100%)"></div></div>
<div style="position:absolute;inset:0;color:#F6F1E8">{mast(1,3)}</div>
<div style="position:absolute;left:66px;top:{ph-70}px;font-family:InterX;font-style:italic;font-weight:800;font-size:22px;color:#F6F1E8;text-shadow:0 2px 8px rgba(0,0,0,.5)">{d.get('caption','')}</div>
<div style="position:absolute;right:56px;top:{ph-200}px;background:{bg};color:{ink};padding:14px 26px 12px;transform:rotate(-4deg);box-shadow:0 18px 40px rgba(0,0,0,.35);text-align:center"><div style="{AN}font-size:120px;line-height:.85">{d['badge'][0]}</div><div style="font-family:InterX;font-style:italic;font-weight:900;font-size:24px;text-transform:uppercase;margin-top:6px">{d['badge'][1]}</div></div>
<div style="position:absolute;left:62px;top:{ph-26}px;transform:rotate(-2deg);background:{ink};color:{bg};font-family:InterX;font-style:italic;font-weight:900;font-size:28px;padding:10px 22px;border-radius:8px">{d.get('kat','CZY WIESZ, ŻE…')}</div>
<div style="position:absolute;left:62px;right:62px;top:{ph+56}px;font-family:InterX;font-style:italic;font-weight:900;font-size:{d.get('ksize',96)}px;line-height:.92;letter-spacing:-.03em;text-transform:uppercase;color:{ink}">{d['khead']}</div>
<div style="position:absolute;left:64px;right:64px;bottom:110px;{CG}font-style:italic;font-size:44px;line-height:1.05;color:{ink}">{d['ksub']}</div>
<div style="position:absolute;left:66px;right:66px;bottom:52px;display:flex;justify-content:space-between;font-size:15px;font-weight:700;letter-spacing:.16em;color:{ink}"><span>PRZESUŃ, BY SPRAWDZIĆ →</span><span>SOLYSOL.PL</span></div>
<div style="position:absolute;right:16px;top:110px;writing-mode:vertical-rl;font-size:13px;color:rgba(246,241,232,.85);white-space:nowrap;text-shadow:0 1px 4px rgba(0,0,0,.6)">{d.get('credit','')}</div>"""
    return page(h).replace('<style>','<style>'+FX+FI,1)
def hef(d,date):
    """Okładka w stylu 'Hefner': czarno-białe zdjęcie po prawej, napisy z lewej, żółty pas na dole."""
    Y='#F6C343'; O='#E0874F'; IVc='#F6F1E8'; ink='#171513'
    h=f"""<div style="position:absolute;inset:0;background:#0e0e10"></div>
<img src="file:///home/claude/photos_raw/{d['photo']}" style="position:absolute;left:{d.get('phleft',300)}px;top:0;width:{1080-d.get('phleft',300)}px;height:1050px;object-fit:cover;object-position:{d['pos']};filter:grayscale(1) contrast(1.12) brightness(.92)">
<div style="position:absolute;inset:0;background-image:radial-gradient(rgba(0,0,0,.22) 1.4px,transparent 1.6px);background-size:8px 8px;opacity:.5"></div>
<div style="position:absolute;left:{d.get('phleft',300)}px;top:0;width:360px;height:1050px;background:linear-gradient(90deg,#0e0e10 0%,rgba(14,14,16,.7) 35%,rgba(14,14,16,0) 100%)"></div>
<div style="position:absolute;left:0;right:0;top:0;height:200px;background:linear-gradient(180deg,rgba(14,14,16,.75),rgba(14,14,16,0))"></div>
<div style="position:absolute;inset:0;color:#F6F1E8">{mast(1,3)}</div>
<div style="position:absolute;left:60px;top:150px;transform:rotate(-3deg);background:{Y};color:{ink};font-family:InterX;font-style:italic;font-weight:900;font-size:30px;padding:10px 22px;box-shadow:6px 6px 0 {O}">{d.get('kat','CZY WIESZ, ŻE…')}</div>
<div style="position:absolute;left:60px;width:{d.get('hw',600)}px;top:225px;{CG}font-weight:600;font-size:{d.get('ksize',96)}px;line-height:.93;color:{IVc};text-shadow:0 4px 20px rgba(0,0,0,.75)">{d['khead']}</div>
<div style="position:absolute;left:62px;width:470px;top:{d.get('ktop',560)}px;font-family:InterX;font-style:italic;font-weight:900;font-size:34px;line-height:1.12;color:{IVc};text-shadow:0 2px 12px rgba(0,0,0,.85)">{d['ksub']}</div>
<div style="position:absolute;left:60px;top:{d.get('btop',740)}px;background:{Y};color:{ink};padding:16px 22px 12px;transform:rotate(-5deg);box-shadow:0 16px 30px rgba(0,0,0,.5);text-align:center"><div style="{AN}font-size:96px;line-height:.85">{d['badge'][0]}</div><div style="font-family:InterX;font-style:italic;font-weight:900;font-size:22px;text-transform:uppercase">{d['badge'][1]}</div></div>
<div style="position:absolute;right:22px;top:1018px;text-align:right;color:rgba(246,241,232,.85);font-size:12px;font-weight:700;text-shadow:0 1px 4px rgba(0,0,0,.8)">{d.get('credit','')}</div>
<div style="position:absolute;left:0;right:0;bottom:0;height:300px;background:{Y}"></div>
<div style="position:absolute;left:60px;right:60px;bottom:128px;font-family:InterX;font-style:italic;font-weight:900;font-size:{d.get('bsize2',62)}px;line-height:.95;letter-spacing:-.03em;text-transform:uppercase;color:{ink}">{d['band']}</div>
<div style="position:absolute;left:62px;right:62px;bottom:52px;display:flex;justify-content:space-between;font-size:15px;font-weight:700;letter-spacing:.16em;color:{ink}"><span>PRZESUŃ, BY SPRAWDZIĆ →</span><span>SOLYSOL.PL</span></div>"""
    return page(h).replace('<style>','<style>'+FX+FI,1)
def quiz(d,date):
    opts=''.join(f'<div style="display:flex;align-items:center;gap:22px;background:{"#E0874F" if i==1 else "rgba(246,241,232,.08)"};border:2px solid {"#E0874F" if i==1 else "rgba(246,241,232,.25)"};border-radius:22px;padding:22px 28px;margin-top:18px"><div style="{AN}font-size:46px;color:{"#171513" if i==1 else "#E0874F"};width:44px">{"ABC"[i]}</div><div style="font-family:InterX;font-style:italic;font-weight:900;font-size:40px;color:{"#171513" if i==1 else "#F6F1E8"}">{o}</div><div style="margin-left:auto;font-size:34px;color:#171513">{"?" if i==1 else ""}</div></div>' for i,o in enumerate(d['opts']))
    opts=opts.replace('background:#E0874F;border:2px solid #E0874F','background:rgba(246,241,232,.08);border:2px solid rgba(246,241,232,.25)').replace('<div style="margin-left:auto;font-size:34px;color:#171513">?</div>','').replace('color:#171513;width:44px','color:#E0874F;width:44px').replace('font-size:40px;color:#171513','font-size:40px;color:#F6F1E8')
    h=f"""<img src="file:///home/claude/photos_raw/{d['photo']}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:{d['pos']};opacity:.35">
<div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(23,21,19,.6),rgba(23,21,19,.92) 45%,#171513)"></div>
{mast(1,3)}
<div style="position:absolute;left:66px;top:170px;transform:rotate(-3deg);background:#E0874F;color:#171513;font-family:InterX;font-style:italic;font-weight:900;font-size:30px;padding:10px 24px;border-radius:12px">QUIZ · ZGADNIJ!</div>
<div style="position:absolute;left:70px;right:70px;top:270px;{CG}font-size:84px;font-weight:500;line-height:1">{d['q']}</div>
<div style="position:absolute;left:70px;right:70px;top:{d.get('otop',640)}px">{opts}</div>
<div style="position:absolute;left:70px;right:70px;bottom:130px;font-family:InterX;font-style:italic;font-weight:800;font-size:32px;color:#E0874F">Odpowiedź na następnym slajdzie →</div>
{foot('NAPISZ W KOMENTARZU: A, B CZY C?')}"""
    return page(h).replace('<style>','<style>'+FX+FI,1)
def liczba(d,date):
    h=f"""<img src="file:///home/claude/photos_raw/{d['photo']}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:{d['pos']}">
<div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(23,21,19,.55),rgba(23,21,19,.25) 35%,rgba(23,21,19,.9) 70%,#171513)"></div>
{mast(1,3)}
<div style="position:absolute;left:50px;right:50px;top:{d.get('ntop',560)}px;{AN}font-size:{d.get('nsize',230)}px;line-height:.85;color:#E0874F;letter-spacing:-.01em;text-shadow:0 8px 40px rgba(0,0,0,.4)">{d['num']}</div>
<div style="position:absolute;left:66px;right:66px;top:{d.get('ntop',560)+d.get('nsize',230)*0.9+20}px;font-family:InterX;font-style:italic;font-weight:900;font-size:50px;line-height:1.08;color:#F6F1E8">{d['numtxt']}</div>
<div style="position:absolute;left:66px;right:66px;top:{d.get('subtop',d.get('ntop',560)+d.get('nsize',230)*0.9+150)}px;font-size:28px;line-height:1.4;color:#E6DED1">{d['numsub']}</div>
<div style="position:absolute;right:30px;top:460px;font-size:14px;color:rgba(246,241,232,.7);transform:rotate(90deg);transform-origin:right top;white-space:nowrap">{d.get('credit','')}</div>
{foot('PRZESUŃ, BY SPRAWDZIĆ  →')}"""
    return page(h).replace('<style>','<style>'+FX+FI,1)

FT=''.join(f"@font-face{{font-family:Typer;src:url(file://{F2}special-elite/files/special-elite-{sub}-400-normal.woff2)}}" for sub in ('latin','latin-ext'))
def akta(d,date):
    rows=''.join(f'<div style="display:flex;gap:14px;padding:9px 0;border-bottom:1px dashed rgba(40,30,20,.35)"><div style="width:190px;color:#6b5a44">{k}</div><div style="flex:1">{v}</div></div>' for k,v in d['fields'])
    h=f"""<div style="position:absolute;inset:0;background:radial-gradient(90% 60% at 50% 45%,#2a2420 0%,#0d0c0b 75%)"></div>
<div style="position:absolute;inset:0;opacity:.18;background-image:repeating-linear-gradient(0deg,rgba(255,255,255,.06) 0 1px,transparent 1px 3px)"></div>
{mast(1,3)}
<div style="position:absolute;left:66px;right:66px;top:150px;font-family:Typer;font-size:26px;letter-spacing:.12em;color:#C0392B">{d.get('kick','AKTA · SPRAWA ZAMKNIĘTA')}</div>
<div style="position:absolute;left:66px;right:66px;top:196px;{CG}font-size:{d.get('hsize',96)}px;font-weight:500;line-height:.95;color:#F6F1E8">{d['ahead']}</div>
<div style="position:absolute;left:120px;top:{d.get('ftop',470)}px;width:860px;height:640px;transform:rotate(-2.5deg)">
 <div style="position:absolute;left:40px;top:-46px;width:300px;height:60px;background:#C9B48A;border-radius:14px 14px 0 0;font-family:Typer;font-size:24px;color:#3b2f22;padding:14px 22px">{d.get('tab','AKTA NR 2007/MRB')}</div>
 <div style="position:absolute;inset:0;background:linear-gradient(160deg,#E2D2AE,#CDB98F);border-radius:6px;box-shadow:0 30px 60px rgba(0,0,0,.6);padding:40px 44px;font-family:Typer;font-size:27px;color:#2b2218;line-height:1.3">
   <div style="width:470px">{rows}</div>
 </div>
 <div style="position:absolute;right:-20px;top:-30px;width:330px;height:400px;background:#f2efe8;padding:12px 12px 52px;transform:rotate(6deg);box-shadow:0 18px 30px rgba(0,0,0,.45)">
   <img src="file:///home/claude/photos_raw/{d['photo']}" style="width:100%;height:100%;object-fit:cover;object-position:{d['pos']};filter:grayscale(1) contrast(1.25) brightness(.9) sepia(.15)">
   <div style="position:absolute;left:14px;bottom:12px;font-family:Typer;font-size:20px;color:#2b2218">{d.get('pcap','Marbella')}</div>
   <div style="position:absolute;left:50%;top:-24px;width:40px;height:70px;border:5px solid #9aa0a6;border-radius:20px;transform:translateX(-50%) rotate(8deg)"></div>
 </div>
 <div style="position:absolute;left:300px;bottom:40px;transform:rotate(-12deg);border:6px solid #C0392B;color:#C0392B;font-family:Typer;font-size:56px;letter-spacing:.08em;padding:8px 26px;opacity:.88;mix-blend-mode:multiply">{d.get('stamp','SKAZANY')}</div>
</div>
<div style="position:absolute;left:66px;right:66px;bottom:118px;font-family:InterX;font-style:italic;font-weight:800;font-size:34px;color:#F6F1E8">{d['tease']}</div>
<div style="position:absolute;right:30px;top:560px;font-size:13px;color:rgba(246,241,232,.5);transform:rotate(90deg);transform-origin:right top;white-space:nowrap">{d.get('credit','')}</div>
{foot('OTWÓRZ AKTA  →')}"""
    return page(h).replace('<style>','<style>'+FX+FI+FT,1)

data=json.load(open(sys.argv[1]))
os.makedirs('html',exist_ok=True)
fbsrc=open('/home/claude/social/fb/gen_fb.py').read()
pre_fb=fbsrc.split("for k in ['n1','n2','n3','n4']:")[0].split("exec(calls)")[1]
for d in data:
    k=d['id']; P.clear()
    if d.get('credit'): CR[d['photo']]=d['credit']
    mast_label=d.get('mast','WIADOMOŚCI')
    cover(k,d['photo'],d['pos'],d['desk'],d['head'],d['deck'])
    facts(k,d['ftitle'],d['pts'],d['note'])
    advice(k,d['atitle'],d['steps'],d['src'])
    # SIATKA IG (22.11.2026): okładka zawsze w stylu mix; hef tylko przy znanych osobach; inne style tylko z keepstyle:true
    if d.get('style') not in ('mix','hef') and not d.get('keepstyle'):
        d['style']='mix'
        if not d.get('badge'):
            p0=(d.get('pts') or [['','','']])[0]
            w=str(p0[1]).split(); lab=''
            for x in w:
                if len(lab+' '+x)>14: break
                lab=(lab+' '+x).strip()
            d['badge']=[str(p0[0]),lab or str(p0[1])[:14],'']
        if len(d['badge'])<3: d['badge']=list(d['badge'])+['']*(3-len(d['badge']))
        n=len(str(d['badge'][0])); d.setdefault('bsize',120 if n<=2 else 96 if n<=4 else 72 if n<=6 else 54)
        d.setdefault('punch2','')
        if not d.get('teaser'):
            t=d.get('deck',''); 
            if len(t)>110: t=t[:110].rsplit(' ',1)[0].rstrip(',;:–- ')+'…'
            d['teaser']=t
        d.setdefault('imgh',900)
    if d.get('style')=='okladka': P[k+'-1']=okladka(d,DATE)
    if d.get('style')=='pop': P[k+'-1']=pop(d,DATE)
    if d.get('style')=='mix': P[k+'-1']=mix(d,DATE)
    for st in ('kolor','kolor2','hef','quiz','liczba','akta'):
        if d.get('style')==st: P[k+'-1']=globals()[st](d,DATE)
    for kk,v in P.items():
        v=v.replace('WIADOMOŚCI · 16.11.2026',f'{mast_label} · {DATE}')
        open(f'html/{kk}.html','w').write(v)
    # FB
    D={k:dict(photo=d['photo'],pos=d['pos'],desk=d['desk'],head=d['head'],pts=d['pts'],steps=d['steps'])}
    ns={'D':D,'P':{},**{n:globals()[n] for n in ['page','tag','kick','CG','INK','IV','ORG','ORL','CR']}}
    exec(pre_fb,ns)
    PF=ns['P']; fbhead=ns['fbhead']; fbfoot=ns['fbfoot']
    dd=D[k]
    ph=''.join(f'<div style="display:grid;grid-template-columns:190px 1fr;gap:22px;padding:22px 0;border-top:1.5px solid #D9CFBF;align-items:center"><span style="{CG}font-size:{48 if len(a)<7 else 38}px;font-weight:600;color:{ORG};line-height:1">{a}</span><div><div style="font-size:25px;font-weight:600;line-height:1.2">{b}</div><div style="font-size:20px;color:#5A534A;margin-top:3px">{c}</div></div></div>' for a,b,c in dd['pts'])
    st=''.join(f'<div style="display:flex;gap:14px;font-size:21px;line-height:1.35;padding:5px 0"><span style="color:{ORL};{CG}font-size:26px;flex:none;width:20px">{i+1}</span><span>{s}</span></div>' for i,s in enumerate(dd['steps'][:3]))
    h=page(f'''{fbhead(dd)}
<div style="position:absolute;left:64px;right:64px;top:552px"><div style="border-bottom:1.5px solid #D9CFBF">{ph}</div></div>
<div style="position:absolute;left:64px;right:64px;bottom:104px;background:{INK};color:{IV};padding:22px 28px">
<div style="font-size:16px;font-weight:700;letter-spacing:.18em;color:{ORL};margin-bottom:6px">{d.get('fbbox','CO ZROBIĆ')}</div>{st}</div>
{fbfoot()}''',IV,INK).replace('WIADOMOŚCI · 16.11.2026',f'{mast_label} · {DATE}').replace("'NARZEKALNIA' if","'NARZEKALNIA' if")
    open(f'html/{k}-fb.html','w').write(h)
print('ok')
